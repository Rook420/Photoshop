function checkCompatibility(clientInfoJSONStr, systemInfoJSONStr) {
    var result = {};
    result.checkResult = 'success';
    return JSON.stringify(result);
}
